# Public evidence derivative

This package cannot reproduce model inference. Obtain the authorised internal analysis record separately. Adding the source does not change this limitation.
