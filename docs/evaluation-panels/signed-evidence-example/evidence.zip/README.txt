Chipmunk Verify public evidence package

Status: DRAFT; report R-7f3a2c1e-02.
evidence.json is the exact frozen evidence set used by the report and API.
assets/ contains all declared evidence images, audio clips and silent video context clips, named by SHA-256.
result.json is a public projection with its own hash, not the original internal result.
Source excerpts and crops are included. The optional source/ file is unredacted user content.
No internal model registry, arbitrary internal artifacts, or original custody event bodies are included.
Custody entries are commitments only; this export cannot prove the completeness of the original event chain.
A valid signature proves integrity and signer identity against a separately obtained key; it does not prove an AI verdict.

Offline verification (obtain the trusted key separately from the issuing instance):
  python -m app.cli verify <package.zip> --public-key <trusted-instance.pem>
Without a trusted key the verifier can only report self-consistency, not authenticate the signer.
Do not run reproduce on this public derivative; see reproduce.md.
